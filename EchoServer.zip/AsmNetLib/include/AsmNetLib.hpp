#pragma once
#pragma comment(lib,"ws2_32.lib") //Winsock Library

#include "Types.h"
#include "ILogger.hpp"
#include "AsmNetwork.h"
#include "Socket.h"
#include "ServerSocket.h"